/* v2.5 economy: rank curve, average Cases multiplier. node tests/update25.test.js
   v2.7: Cases return is now ~112.2% (Pirate Token 0.05%, rare tiers slightly more common). */
const fs=require('fs'),vm=require('vm'),path=require('path');let pass=0,fail=0;const t=(n,ok)=>{console.log((ok?'PASS ':'FAIL ')+n);ok?pass++:fail++};
const sb={console,Math,Date,localStorage:{getItem(){return null},setItem(){},removeItem(){}}};vm.createContext(sb);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../js/config.js'),'utf8')+';this.CFG=CFG',sb);const R=sb.CFG.RANKS;
const reqs=R.filter(r=>r.req).map(r=>r.req.c);
t('v3.0: 46 rank-ups (Unranked..Bedrock III), requirements strictly increasing',reqs.length===46&&reqs.every((c,i)=>i===0||c>reqs[i-1]));
t('highest requirement stays below 3,500,000 (Bedrock II -> Bedrock III is 3,320,000)',Math.max(...reqs)<=3500000);
t('rank round requirements (Unranked 40 .. Division 2 2400, then Division 1 .. Bedrock II 2600 .. 4000)',JSON.stringify(R.filter(r=>r.req).map(r=>r.req.r))==='[40,50,70,80,160,240,320,480,600,800,800,800,800,1000,1000,1200,1200,1200,1400,1600,1600,1200,1200,1400,1400,1400,1600,1600,1600,2000,2000,2400,2400,2400,2600,2600,2800,2800,3000,3000,3200,3200,3400,3600,3800,4000]');
// RTP of Cases from source
const src=fs.readFileSync(path.join(__dirname,'../js/games/cases.js'),'utf8');
const rows=[...src.matchAll(/min: ([\d.]+),\s*max: ([\d.]+),\s*p: ([\d.]+)/g)].map(m=>[+m[1],+m[2],+m[3]]);
const rtp=rows.reduce((a,[lo,hi,p])=>a+p/100*(lo+hi)/2,0);
t('Cases return is about 104.5% incl. the 0.04% Pirate Token (v2.95) ('+(rtp*100).toFixed(1)+'%)',Math.abs(rtp-1.0454)<.003);
console.log(pass+' passed, '+fail+' failed');process.exit(fail?1:0);
