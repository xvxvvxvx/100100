#!/bin/sh
# Update 3.1: delete files removed by the update. Run from the repository root.
rm -f js/calc.js js/ptable.js js/toggle.js js/games/lockpick.js
rm -f security.test.js tests/economy.test.js tests/security.test.js tests/update23.test.js tests/update27.test.js tests/update275.test.js tests/update28.test.js tests/update295.test.js tests/update30.test.js
echo "Update 3.1 cleanup done."
